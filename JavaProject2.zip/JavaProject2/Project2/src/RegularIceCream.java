public abstract class RegularIceCream extends IceCream {
   
     private int scoops;
    
    public RegularIceCream(String id, String f, int q, int s) {
        super(id, f, q);
        this.scoops = s;
    }
    
    public int getScoops() { return scoops; }
    public void setScoops(int s) { this.scoops = s; }
    
    @Override
    public String toString() {
        return super.toString() + ", Scoops: " + scoops + ", Type: Regular";
    }
    
}
