import java.io.*;
import java.util.*;

public class Shop implements Serializable {
    private String shopName;
    public Cart[] carts;
    public int numCarts;
    private int maxCarts = 5;

    public Shop(String name) {
        this.shopName = name;
        this.carts = new Cart[maxCarts];
        this.numCarts = 0;
    }

    public void addCart(Cart cart) {
        if (numCarts < maxCarts) {
            carts[numCarts++] = cart;
        }
    }

    public boolean emptyCart(String cartId) {
        for (int i = 0; i < numCarts; i++) {
            if (carts[i].getCartId().equals(cartId)) {
                carts[i].emptyCart();
                return true;
            }
        }
        return false;
    }

    public Cart searchCart(String cartId) {
        for (int i = 0; i < numCarts; i++) {
            if (carts[i].getCartId().equals(cartId)) {
                return carts[i];
            }
        }
        return null;
    }

   public void saveCartsData() {
    try (PrintWriter writer = new PrintWriter(new FileWriter("Shop_Summary.txt"))) {
        // كتابة ملخص المتجر
        writer.println("=== Sweet Treats Shop Summary ===");
        writer.println("Total Carts: " + numCarts);
        writer.println("Last Updated: " + new Date());
        writer.println("==============================");
        
        // كتابة ملخص لكل عربة
        for (int i = 0; i < numCarts; i++) {
            Cart cart = carts[i];
            writer.println("\nCart ID: " + cart.getCartId());
            writer.println("Items Count: " + cart.CountIceCream());
            writer.println("Total Value: $" + String.format("%.2f", cart.calculateTotal()));
        }
    } catch (IOException e) {
        System.out.println("Error saving shop summary: " + e.getMessage());
    }
}

public void loadCartsData() {
    try (Scanner scanner = new Scanner(new File("Carts.txt"))) {
        numCarts = Integer.parseInt(scanner.nextLine());
        carts = new Cart[maxCarts]; // إعادة تهيئة المصفوفة
        
        for (int i = 0; i < numCarts; i++) {
            String cartId = scanner.nextLine();
            int itemCount = Integer.parseInt(scanner.nextLine());
            carts[i] = new Cart(cartId); // تهيئة كل عنصر في المصفوفة
        }
    } catch (FileNotFoundException e) {
        System.out.println("No saved data found. Starting new shop.");
    } catch (Exception e) {
        System.out.println("Error loading shop data: " + e.getMessage());
    }
}

    // Getters
    public String getShopName() { return shopName; }
    public int getNumCarts() { return numCarts; }
    public Cart[] getCarts() { return carts; }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Shop Name: ").append(shopName).append("\n");
        sb.append("Number of Carts: ").append(numCarts).append("\n");
        for (int i = 0; i < numCarts; i++) {
            sb.append(carts[i].toString()).append("\n");
        }
        return sb.toString();
    }
}