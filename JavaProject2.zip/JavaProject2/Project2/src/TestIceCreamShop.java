import java.io.*; //File
import java.util.*; //Scanner
import javax.swing.*; //JOptionpane

public class TestIceCreamShop {
    
    private static Scanner input = new Scanner(System.in);
public static Shop shop = new Shop("Sweet Treats");
    public static Cart cart1 = new Cart("1");
    public static Cart cart2 = new Cart("2");
    public static Cart cart3 = new Cart("3");
    public static Cart cart4 = new Cart("4");
    public static Cart cart5 = new Cart("5");
        
    public static void main(String[] args) {
    // Delete old data files if they cause problems
    new File("Carts.txt").delete();
    for (int i = 1; i <= 5; i++) {
        new File("IceCream_" + i + ".txt").delete();
    }

    // Initialize shop
    
    // Try to load data
    shop.loadCartsData();
    
    // If no saved data, create default carts
    if (shop.getNumCarts() == 0) {
     shop.addCart(cart1);
        shop.addCart(cart2);
        shop.addCart(cart3);
        shop.addCart(cart4);
        shop.addCart(cart5);
    
        Frame1 f = new Frame1();
        f.setVisible(true);
        
        int choice;
        do {
            System.out.println("\n***** Ice Cream Shop Menu *******");
            System.out.println("1. Manage Carts");
            System.out.println("2. Order Ice Cream");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            
            try {
                choice = input.nextInt();
                input.nextLine(); // Cleaning
                
                switch (choice) {
                    case 1:
                        manageCartsMenu();
                        break;
                    case 2:
                        orderIceCreamMenu();
                        break;
                    case 3:
                        exitProgram();
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter 1-3.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Please enter numbers only!");
                input.nextLine();
                choice = 0;
            }
        } while (choice != 3);
    }
    }

    public static void manageCartsMenu() {
        int choice;
        do {
            System.out.println("\n***** Manage Carts Menu *******");
            System.out.println("1. Checkout Cart");
            System.out.println("2. Empty Cart");
            System.out.println("3. Search Cart");
            System.out.println("4. View All Carts");
            System.out.println("5. Back to Main Menu");
            System.out.print("Enter your choice: ");
            
            try {
                choice = input.nextInt();
                input.nextLine();
                
                switch (choice) {
                    case 1:
                        checkoutCart();
                        break;
                    case 2:
                        emptyCart();
                        break;
                    case 3:
                        searchCart();
                        break;
                    case 4:
                        viewAllCarts();
                        break;
                    case 5:
                        System.out.println("Returning to main menu...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter 1-5.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Please enter numbers only!");
                input.nextLine();
                choice = 0;
            }
        } while (choice != 5);
    }
    
    public static void emptyCart() {
        System.out.print("Enter cart ID to empty (1-5): ");
        String cartId = input.nextLine();
        
        if (shop.emptyCart(cartId)) {
            System.out.println("Cart removed successfully!");
        } else {
            System.out.println("Cart not found or could not be removed.");
        }
    }
    
    public static void searchCart() {
        System.out.print("Enter cart ID to search (1-5): ");
        String cartId = input.nextLine();
        
        Cart cart = shop.searchCart(cartId);
       if (Integer.parseInt(cartId) > 1 || Integer.parseInt(cartId) < 5) {
            System.out.println("\nCart Details:");
            System.out.println(cart);
        } else {
            System.out.println("Invalid cart id! try again");
        }
    }
    
    public static void viewAllCarts() {
        if (shop.getNumCarts() == 0) {
            System.out.println("No carts available!");
            return;
        }
        
        System.out.println("\nAll Carts in Shop:");
        System.out.println(shop);
    }
    
    public static void checkoutCart() {
        System.out.print("Enter cart ID to checkout (1-5): ");
        String cartId = input.nextLine();
        
        Cart cart = shop.searchCart(cartId);
       if (Integer.parseInt(cartId) < 1 || Integer.parseInt(cartId) > 5) {
            System.out.println("Invalid cart id! try again");
            return;
        }
        
        if (cart.CountIceCream() == 0) {
            System.out.println("Cannot checkout an empty cart!");
            return;
        }
        
        System.out.println("\n--- Checkout Summary ---");
        System.out.println(cart);
        System.out.println("Thank you for your purchase!");
        
        shop.emptyCart(cartId);
    }
    
    public static void orderIceCreamMenu() {
        int choice;
        do {
            System.out.println("\n***** Order Ice Cream Menu *******");
            System.out.println("1. Add Ice Cream to Cart");
            System.out.println("2. Remove Ice Cream from Cart");
            System.out.println("3. Search Ice Cream in Cart");
            System.out.println("4. Back to Main Menu");
            System.out.print("Enter your choice: ");
            
            try {
                choice = input.nextInt();
                input.nextLine();
                
                switch (choice) {
                    case 1:
                        addIceCream();
                        break;
                    case 2:
                        removeIceCream();
                        break;
                    case 3:
                        searchIceCream();
                        break;
                    case 4:
                        System.out.println("Returning to main menu...");
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter 1-4.");
                }
            } catch (InputMismatchException e) {
                System.out.println("Please enter numbers only!");
                input.nextLine();
                choice = 0;
            }
        } while (choice != 4);
    }
    
    public static void addIceCream() {
        System.out.print("Enter cart ID: ");
        String cartId = input.nextLine();
        
        Cart cart = shop.searchCart(cartId);
        if (Integer.parseInt(cartId) < 1 || Integer.parseInt(cartId) > 5) {
            System.out.println("Invalid cart id! try again");
            return;
        }
        
        try {
            System.out.println("Select ice cream type:");
            System.out.println("1. Regular Ice Cream");
            System.out.println("2. Special Ice Cream");
            System.out.print("Enter choice: ");
            int typeChoice = input.nextInt();
            input.nextLine();
            
            if (typeChoice < 1 || typeChoice > 2) {
                System.out.println("Invalid choice!");
                return;
            }
            
            System.out.println("Select flavor:");
            if (typeChoice == 1) {
                System.out.println("1. Vanilla");
                System.out.println("2. Chocolate");
            } else {
                System.out.println("1. Sugar-Free Vanilla");
                System.out.println("2. Sugar-Free Chocolate");
            }
            System.out.print("Enter choice: ");
            int flavorChoice = input.nextInt();
            input.nextLine();
            
            if (flavorChoice < 1 || flavorChoice > 2) {
                System.out.println("Invalid choice!");
                return;
            }
            
            System.out.print("Enter ice cream ID: ");
            String iceCreamId = input.nextLine();
            
            System.out.print("Enter quantity: ");
            int quantity = input.nextInt();
            
            System.out.print("Enter number of scoops: ");
            int scoops = input.nextInt();
            input.nextLine();
            
            IceCream iceCream;
            if (typeChoice == 1) {
                if (flavorChoice == 1) {
                    iceCream = new Vanilla(iceCreamId, "Vanilla", quantity, scoops);
                } else {
                    iceCream = new Chocolate(iceCreamId, "Chocolate", quantity, scoops);
                }
            } else {
                if (flavorChoice == 1) {
                    iceCream = new SugarFreeVanilla(iceCreamId, "Sugar-Free Vanilla", quantity, scoops);
                } else {
                    iceCream = new SugarFreeChocolate(iceCreamId, "Sugar-Free Chocolate", quantity, scoops);
                }
            }
            
            try {
                if (cart.addIceCream(iceCream)) {
                    System.out.println("Ice cream added successfully!");
                }
            } catch (InvalidCartException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } catch (InputMismatchException e) {
            System.out.println("Invalid input! Please enter numbers where required.");
            input.nextLine();
        }
    }
    
    public static void removeIceCream() {
        System.out.print("Enter cart ID: ");
        String cartId = input.nextLine();
        
        Cart cart = shop.searchCart(cartId);
        if (Integer.parseInt(cartId) < 1 || Integer.parseInt(cartId) > 5) {
            System.out.println("Invalid cart id! try again");
            return;
        }
        
        System.out.print("Enter ice cream ID to remove: ");
        String iceCreamId = input.nextLine();
        
        if (cart.removeIceCream(iceCreamId)) {
            System.out.println("Ice cream removed successfully!");
        } else {
            System.out.println("Ice cream not found in this cart!");
        }
    }
    
    public static void searchIceCream() {
        System.out.print("Enter cart ID: ");
        String cartId = input.nextLine();
        
        Cart cart = shop.searchCart(cartId);
        if (Integer.parseInt(cartId) < 1 || Integer.parseInt(cartId) > 5) {
            System.out.println("Invalid cart id! try again");
            return;
        }
        
        System.out.print("Enter ice cream ID to search: ");
        String iceCreamId = input.nextLine();
        
        IceCream iceCream = cart.searchIceCream(iceCreamId);
        if (iceCream != null) {
            System.out.println("\nIce Cream Details:");
            System.out.println(iceCream);
        } else {
            System.out.println("Ice cream not found in this cart!");
        }
    }
    public static void exitProgram() {
    System.out.println("Saving data before exiting...");
    shop.saveCartsData();
    for (int i = 1; i <= 5; i++) {
        Cart cart = shop.searchCart(String.valueOf(i));
        if (cart != null) {
            cart.saveIceCreamData();
        }
    }
    System.out.println("Thank you for using Sweet Treats Ice Cream Shop!");
    System.exit(0);
}
}
