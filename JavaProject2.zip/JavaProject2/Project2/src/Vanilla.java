public class Vanilla extends RegularIceCream {
    
        public Vanilla(String id, String f, int q, int s) {
        super(id, f, q, s);
    }

    @Override
    public double calculatePrice() {
        return (5 * getScoops()) * getQuantity();
    }

    @Override
    public String toString() {
        return super.toString() + ", Price: $" + calculatePrice();
    }
    
}
