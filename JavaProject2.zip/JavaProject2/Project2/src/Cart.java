import java.io.*;
import java.util.*;

public class Cart implements Serializable {
    private String cartId;
    private Node headIceCream; // يستخدم الكلاس Node المنفصل
    private int maxItems = 10;

    public Cart(String id) {
        this.cartId = id;
        this.headIceCream = null;
    }

    // تم إزالة تعريف Node الداخلي لأننا نستخدم الكلاس المنفصل

    public int CountIceCream() {
        int count = 0;
        Node current = headIceCream;
        while (current != null) {
            count++;
            current = current.getNext(); // استخدام getNext() بدلاً من .next
        }
        return count;
    }

    public boolean addIceCream(IceCream iceCream) throws InvalidCartException {
        if (CountIceCream() >= maxItems) {
            throw new InvalidCartException("Cart is full! Maximum items reached.");
        }

        if (containsIceCreamId(iceCream.getIceCreamId())) {
            return false;
        }

        Node newNode = new Node(iceCream);
        newNode.setNext(headIceCream); // استخدام setNext() بدلاً من .next
        headIceCream = newNode;
        return true;
    }

    public boolean removeIceCream(String iceCreamId) {
        if (headIceCream == null) return false;

        if (headIceCream.getData().getIceCreamId().equals(iceCreamId)) {
            headIceCream = headIceCream.getNext();
            return true;
        }

        Node prev = headIceCream;
        Node current = headIceCream.getNext();

        while (current != null) {
            if (current.getData().getIceCreamId().equals(iceCreamId)) {
                prev.setNext(current.getNext());
                return true;
            }
            prev = current;
            current = current.getNext();
        }
        return false;
    }

    public void emptyCart() {
        headIceCream = null;
    }

    public IceCream searchIceCream(String iceCreamId) {
        Node current = headIceCream;
        while (current != null) {
            if (current.getData().getIceCreamId().equals(iceCreamId)) {
                return current.getData();
            }
            current = current.getNext();
        }
        return null;
    }

    public boolean containsIceCreamId(String id) {
        Node current = headIceCream;
        while (current != null) {
            if (current.getData().getIceCreamId().equals(id)) {
                return true;
            }
            current = current.getNext();
        }
        return false;
    }

    public double calculateTotal() {
        double total = 0;
        Node current = headIceCream;
        while (current != null) {
            total += current.getData().calculatePrice();
            current = current.getNext();
        }
        return total;
    }

   public void saveIceCreamData() {
    try (PrintWriter writer = new PrintWriter(new FileWriter("Cart_" + cartId + "_Details.txt"))) {
        // كتابة معلومات العربة الأساسية
        writer.println("=== Cart Information ===");
        writer.println("Cart ID: " + cartId);
        writer.println("Total Items: " + CountIceCream());
        writer.println("Total Price: $" + String.format("%.2f", calculateTotal()));
        writer.println("=======================");
        
        // كتابة تفاصيل كل آيس كريم
        writer.println("\n=== Ice Cream Items ===");
        Node current = headIceCream;
        int itemNumber = 1;
        
        while (current != null) {
            IceCream iceCream = current.getData();
            writer.println("\nItem #" + itemNumber++);
            writer.println("ID: " + iceCream.getIceCreamId());
            writer.println("Flavor: " + iceCream.getFlavor());
            writer.println("Quantity: " + iceCream.getQuantity());
            
            if (iceCream instanceof RegularIceCream) {
                writer.println("Type: Regular");
                writer.println("Scoops: " + ((RegularIceCream)iceCream).getScoops());
            } else {
                writer.println("Type: Special");
                writer.println("Scoops: " + ((SpecialIceCream)iceCream).getScoops());
            }
            
            writer.println("Price: $" + iceCream.calculatePrice());
            current = current.getNext();
        }
    } catch (IOException e) {
        System.out.println("Error saving cart data: " + e.getMessage());
    }
}

   public void loadIceCreamData() {
    try (Scanner scanner = new Scanner(new File("Cart_" + cartId + "_Details.txt"))) {
        // تخطي رأس الملف
        while (scanner.hasNextLine() && !scanner.nextLine().contains("=== Ice Cream Items ===")) {
            // انتقل حتى قسم الآيس كريم
        }
        
        emptyCart(); // إفراغ العربة الحالية
        
        // قراءة كل عنصر آيس كريم
        while (scanner.hasNextLine()) {
            String line = scanner.nextLine();
            if (line.startsWith("Item #")) {
                String iceCreamId = scanner.nextLine().split(": ")[1];
                String flavor = scanner.nextLine().split(": ")[1];
                int quantity = Integer.parseInt(scanner.nextLine().split(": ")[1]);
                String type = scanner.nextLine().split(": ")[1];
                int scoops = Integer.parseInt(scanner.nextLine().split(": ")[1]);
                scanner.nextLine(); // تخطي سعر العنصر
                
                IceCream iceCream;
                if (type.equals("Regular")) {
                    if (flavor.equals("Vanilla")) {
                        iceCream = new Vanilla(iceCreamId, flavor, quantity, scoops);
                    } else {
                        iceCream = new Chocolate(iceCreamId, flavor, quantity, scoops);
                    }
                } else {
                    if (flavor.equals("Sugar-Free Vanilla")) {
                        iceCream = new SugarFreeVanilla(iceCreamId, flavor, quantity, scoops);
                    } else {
                        iceCream = new SugarFreeChocolate(iceCreamId, flavor, quantity, scoops);
                    }
                }
                
                // إضافة الآيس كريم للعربة
                Node newNode = new Node(iceCream);
                newNode.setNext(headIceCream);
                headIceCream = newNode;
            }
        }
    } catch (FileNotFoundException e) {
        System.out.println("No saved data found for cart " + cartId);
    } catch (Exception e) {
        System.out.println("Error loading cart data: " + e.getMessage());
    }
}


    // Getters
    public String getCartId() { return cartId; }
    public int getMaxItems() { return maxItems; }
    public Node getHeadIceCream() { return headIceCream; }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Cart ID: ").append(cartId).append("\n");
        sb.append("Number of items: ").append(CountIceCream()).append("\n");
        sb.append("Items:\n");
        
        Node current = headIceCream;
        while (current != null) {
            sb.append(current.getData().toString()).append("\n");
            current = current.getNext();
        }
        
        sb.append("Total: $").append(String.format("%.2f", calculateTotal())).append("\n");
        return sb.toString();
    }
}