
import java.io.*;
import java.util.*;

public abstract class IceCream implements Serializable {
    
    private String iceCreamId;
    private String flavor;
    private int quantity;

    public IceCream(String id, String f, int q) {
        this.iceCreamId = id;
        this.flavor = f;
        this.quantity = q;
    }

    public abstract double calculatePrice();

    // Getters and setters
    public String getIceCreamId() { return iceCreamId; }
    public String getFlavor() { return flavor; }
    public int getQuantity() { return quantity; }
    
    public void setIceCreamId(String id) { this.iceCreamId = id; }
    public void setFlavor(String f) { this.flavor = f; }
    public void setQuantity(int q) { this.quantity = q; }

    @Override
    public String toString() {
        return "ID: " + iceCreamId + ", Flavor: " + flavor + ", Quantity: " + quantity;
    }

}