public class SugarFreeVanilla extends SpecialIceCream {
    
        public SugarFreeVanilla(String id, String f, int q, int s) {
        super(id, f, q, s);
    }

    @Override
    public double calculatePrice() {
        return (10 * getScoops()) * getQuantity();
    }

    @Override
    public String toString() {
        return super.toString() + ", Price: $" + calculatePrice();
    }
    
}
