import java.io.*;

public class Node implements Serializable {
    
    private IceCream data;
    private Node next;

    public Node(IceCream iceCream) {
        this.data = iceCream;
        this.next = null;
    }

    // Setters and Getters
    public void setNext(Node next) { this.next = next; }
    public Node getNext() { return next; }

    public void setData(IceCream data) { this.data = data; }
    public IceCream getData() { return data; }
    
}
