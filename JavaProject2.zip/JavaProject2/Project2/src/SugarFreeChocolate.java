public class SugarFreeChocolate extends SpecialIceCream  {
    
        public SugarFreeChocolate(String id, String f, int q, int s) {
        super(id, f, q, s);
    }

    @Override
    public double calculatePrice() {
        return (15 * getScoops()) * getQuantity();
    }

    @Override
    public String toString() {
        return super.toString() + ", Price: $" + calculatePrice();
    }
    
}
