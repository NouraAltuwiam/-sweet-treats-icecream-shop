public class Chocolate extends RegularIceCream {
    
        public Chocolate(String id, String f, int q, int s) {
        super(id, f, q, s);
    }

    @Override
    public double calculatePrice() {
        return (7 * getScoops()) * getQuantity();
    }

    @Override
    public String toString() {
        return super.toString() + ", Price: $" + calculatePrice();
    }
    
}
